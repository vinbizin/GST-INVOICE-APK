package com.example.gstinvoicegenerator

import android.app.Application
import android.util.Log

class GSTInvoiceApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.d("GSTInvoiceApplication", "Application initialized")
        // Initialize any necessary components here
    }
}

