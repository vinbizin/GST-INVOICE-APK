package com.example.gstinvoicegenerator.models

import java.time.LocalDate

data class InvoiceData(
    val customerName: String = "",
    val address: String = "",
    val mobile: String = "",
    val panAadhar: String = "",
    val gstin: String = "",
    val isInterState: Boolean = false,
    val vehicleNo: String = "",
    val driverName: String = "",
    val driverMobile: String = "",
    val lineItems: List<LineItem> = listOf(),
    val date: String = LocalDate.now().toString(),
    val invoiceNumber: String = ""
)

data class LineItem(
    val particulars: String = "",
    val hsn: String = "",
    val quantity: Int = 0,
    val weight: Double = 0.0,
    val rate: Double = 0.0,
    val gstRate: Double = 0.18
) {
    val amount: Double
        get() = quantity * rate
}

