package com.example.gstinvoicegenerator.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.gstinvoicegenerator.models.LineItem
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LineItemsForm(
    lineItems: List<LineItem>,
    onAddItem: () -> Unit,
    onRemoveItem: (Int) -> Unit,
    onUpdateItem: (Int, String, Any) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Line Items",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            lineItems.forEachIndexed { index, item ->
                LineItemRow(
                    item = item,
                    onUpdate = { field, value -> onUpdateItem(index, field, value) },
                    onRemove = { onRemoveItem(index) }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
            Button(
                onClick = onAddItem,
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Add Item")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LineItemRow(
    item: LineItem,
    onUpdate: (String, Any) -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        OutlinedTextField(
            value = item.particulars,
            onValueChange = { onUpdate("particulars", it) },
            label = { Text("Particulars") },
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        OutlinedTextField(
            value = item.hsn,
            onValueChange = { onUpdate("hsn", it) },
            label = { Text("HSN") },
            modifier = Modifier.weight(0.5f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        OutlinedTextField(
            value = item.quantity.toString(),
            onValueChange = { onUpdate("quantity", it.toIntOrNull() ?: 0) },
            label = { Text("Qty") },
            modifier = Modifier.weight(0.3f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        OutlinedTextField(
            value = item.rate.toString(),
            onValueChange = { onUpdate("rate", it.toDoubleOrNull() ?: 0.0) },
            label = { Text("Rate") },
            modifier = Modifier.weight(0.4f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(onClick = onRemove) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove item")
        }
    }
}

