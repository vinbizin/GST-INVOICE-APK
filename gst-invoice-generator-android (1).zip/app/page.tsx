"use client"

import InvoiceForm from "../components/InvoiceForm"

export default function SyntheticV0PageForDeployment() {
  return <InvoiceForm />
}