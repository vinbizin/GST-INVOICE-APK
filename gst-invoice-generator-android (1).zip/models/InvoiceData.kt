package com.example.gstinvoicegenerator.models

data class InvoiceData(
    val customerName: String = "",
    val address: String = "",
    val mobile: String = "",
    val panAadhar: String = "",
    val gstin: String = "",
    val isInterState: Boolean = false,
    val vehicleNo: String = "",
    val driverName: String = "",
    val driverMobile: String = "",
    val lineItems: List<LineItem> = listOf(),
    val date: String = java.time.LocalDate.now().toString()
)

data class LineItem(
    val particulars: String = "",
    val hsn: String = "",
    val quantity: Int = 0,
    val weight: Double = 0.0,
    val rate: Double = 0.0
) {
    val amount: Double
        get() = quantity * rate
}

