export const gstRates = [
  { value: 0, label: "0% (Exempt)" },
  { value: 0.05, label: "5%" },
  { value: 0.12, label: "12%" },
  { value: 0.18, label: "18%" },
  { value: 0.28, label: "28%" }
]

// Common HSN codes for roofing industry
export const commonHsnCodes = [
  { code: "7308", description: "Roofing sheets & structures" },
  { code: "8302", description: "Rolling shutters & fittings" },
  { code: "7308 90 10", description: "Galvanized steel sheets" },
]

// Common items in roofing business
export const commonItems = [
  "Color Coated Roofing Sheets",
  "Rolling Shutter",
  "Galvanized Sheets",
  "Installation Service",
  "Repair Service"
]

