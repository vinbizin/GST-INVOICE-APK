package com.example.gstinvoicegenerator.utils

import android.content.Context
import android.graphics.pdf.PdfDocument
import android.os.Environment
import com.example.gstinvoicegenerator.models.InvoiceData
import java.io.File
import java.io.FileOutputStream

object PDFGenerator {
    fun generateInvoicePDF(context: Context, invoiceData: InvoiceData): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)

        val canvas = page.canvas
        val paint = android.graphics.Paint()

        // Company header
        paint.textSize = 24f
        paint.color = android.graphics.Color.rgb(30, 27, 75)
        canvas.drawText("SUJAY ENTERPRISES", 50f, 50f, paint)

        paint.textSize = 12f
        paint.color = android.graphics.Color.BLACK
        canvas.drawText("Colour Coated Roofing Sheets & Rolling Shutter Manufacturer", 50f, 70f, paint)
        canvas.drawText("Factory: A-95, Nardana MIDC, Hablabi Path, Dhule 424599, (MH.)", 50f, 90f, paint)
        canvas.drawText("Office: Plot No.24, Govardhan Nagar, Near Chavara School, Walwadi, Dhule-424002", 50f, 110f, paint)
        canvas.drawText("Contact: 9422787094, 7083951715", 50f, 130f, paint)
        canvas.drawText("GSTIN: 27BBQPB0277E1ZS | PAN: BBQPB0277E", 50f, 150f, paint)

        // Invoice details
        paint.textSize = 16f
        canvas.drawText("GST Invoice", 50f, 190f, paint)
        paint.textSize = 12f
        canvas.drawText("Invoice No: ${invoiceData.invoiceNumber}", 50f, 210f, paint)
        canvas.drawText("Date: ${invoiceData.date}", 350f, 210f, paint)

        // Customer details
        canvas.drawText("Customer: ${invoiceData.customerName}", 50f, 250f, paint)
        canvas.drawText("Address: ${invoiceData.address}", 50f, 270f, paint)
        canvas.drawText("Mobile: ${invoiceData.mobile}", 50f, 290f, paint)
        canvas.drawText("GSTIN: ${invoiceData.gstin}", 50f, 310f, paint)

        // Vehicle details
        canvas.drawText("Vehicle No: ${invoiceData.vehicleNo}", 350f, 250f, paint)
        canvas.drawText("Driver: ${invoiceData.driverName}", 350f, 270f, paint)
        canvas.drawText("Driver Mobile: ${invoiceData.driverMobile}", 350f, 290f, paint)

        // Line items
        paint.textSize = 14f
        canvas.drawText("Sr.", 50f, 350f, paint)
        canvas.drawText("Particulars", 80f, 350f, paint)
        canvas.drawText("HSN", 230f, 350f, paint)
        canvas.drawText("Qty", 280f, 350f, paint)
        canvas.drawText("Rate", 330f, 350f, paint)
        canvas.drawText("Amount", 400f, 350f, paint)
        canvas.drawText("GST", 470f, 350f, paint)

        paint.textSize = 12f
        var y = 380f
        invoiceData.lineItems.forEachIndexed { index, item ->
            canvas.drawText((index + 1).toString(), 50f, y, paint)
            canvas.drawText(item.particulars, 80f, y, paint)
            canvas.drawText(item.hsn, 230f, y, paint)
            canvas.drawText(item.quantity.toString(), 280f, y, paint)
            canvas.drawText("₹${String.format("%.2f", item.rate)}", 330f, y, paint)
            canvas.drawText("₹${String.format("%.2f", item.amount)}", 400f, y, paint)
            canvas.drawText("${(item.gstRate * 100).toInt()}%", 470f, y, paint)
            y += 20f
        }

        // Totals
        y += 20f
        val subtotal = invoiceData.lineItems.sumOf { it.amount }
        val gst = calculateGST(invoiceData.lineItems)
        canvas.drawText("Subtotal: ₹${String.format("%.2f", subtotal)}", 350f, y, paint)
        y += 20f
        if (invoiceData.isInterState) {
            canvas.drawText("IGST: ₹${String.format("%.2f", gst["igst"])}", 350f, y, paint)
        } else {
            canvas.drawText("SGST: ₹${String.format("%.2f", gst["sgst"])}", 350f, y, paint)
            y += 20f
            canvas.drawText("CGST: ₹${String.format("%.2f", gst["cgst"])}", 350f, y, paint)
        }
        y += 20f
        paint.textSize = 16f
        canvas.drawText("Total: ₹${String.format("%.2f", subtotal + gst.values.sum())}", 350f, y, paint)

        // Bank details
        y += 40f
        paint.textSize = 12f
        canvas.drawText("Bank Details:", 50f, y, paint)
        y += 20f
        canvas.drawText("SUJAY ENTERPRISES", 50f, y, paint)
        y += 20f
        canvas.drawText("Bank: Union Bank of India", 50f, y, paint)
        y += 20f
        canvas.drawText("A/c No.: 165721010000088", 50f, y, paint)
        y += 20f
        canvas.drawText("IFSC: UBIN0916579", 50f, y, paint)

        // Terms and conditions
        y += 40f
        canvas.drawText("Terms & Conditions:", 50f, y, paint)
        y += 20f
        invoiceData.termsAndConditions.forEachIndexed { index, term ->
            canvas.drawText("${index + 1}. $term", 50f, y, paint)
            y += 20f
        }

        pdfDocument.finishPage(page)

        val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "invoice_${invoiceData.date}.pdf")
        pdfDocument.writeTo(FileOutputStream(file))
        pdfDocument.close()

        return file
    }

    private fun calculateGST(lineItems: List<InvoiceData.LineItem>): Map<String, Double> {
        val totalGST = lineItems.sumOf { it.amount * it.gstRate }
        return mapOf(
            "sgst" to totalGST / 2,
            "cgst" to totalGST / 2,
            "igst" to totalGST
        )
    }
}

