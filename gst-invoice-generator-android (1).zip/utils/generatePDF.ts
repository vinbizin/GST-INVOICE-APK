import { jsPDF } from "jspdf"
import { InvoiceData } from "../types"

export const generatePDF = (invoice: InvoiceData) => {
  const pdf = new jsPDF()
  
  // Add logo
  const logo = new Image()
  logo.src = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Sujay%20logo-1-sVoEfFwreG101KwejK4AIqel8NdHUi.png"
  pdf.addImage(logo, "PNG", 70, 10, 60, 30)
  
  // Company header
  pdf.setTextColor(30, 27, 75) // Navy blue color
  pdf.setFontSize(20)
  pdf.text("SUJAY ENTERPRISES", 50, 50)
  
  pdf.setTextColor(0)
  pdf.setFontSize(10)
  
  // Company details
  pdf.text("* Colour Coated Roofing Sheets & Rolling Shutter Manufacturer", 50, 60)
  pdf.text("Factory :- A-95, Nardana MIDC, Hablabi Path, Dhule 424599, (MH.)", 20, 70)
  pdf.text("Office :- Plot No.24, Govardhan Nagar, Near Chavara School, Walwadi, Dhule-424002", 20, 75)
  pdf.text("Contact No. :- 9422787094, 7083951715", 20, 80)
  pdf.text("GSTIN NO. : 27BBQPB0277E1ZS", 20, 85)
  pdf.text("PAN : BBQPB0277E", 20, 90)
  
  // Invoice details
  pdf.text(`Invoice No: ${invoice.invoiceNumber}`, 20, 100)
  pdf.text(`Date: ${invoice.date}`, 150, 100)
  pdf.text(`Reference Code: ${invoice.referenceCode}`, 20, 105)
  
  // Customer details
  pdf.text(`Customer Name: ${invoice.customerName}`, 20, 115)
  pdf.text(`Address: ${invoice.address}`, 20, 120)
  pdf.text(`Mobile: ${invoice.mobile}`, 20, 125)
  pdf.text(`PAN/Aadhar: ${invoice.panAadhar}`, 20, 130)
  pdf.text(`GSTIN: ${invoice.gstin}`, 20, 135)
  
  // Vehicle details
  pdf.text(`Vehicle No.: ${invoice.vehicleNo}`, 120, 115)
  pdf.text(`Driver Name: ${invoice.driverName}`, 120, 120)
  pdf.text(`Driver Mobile: ${invoice.driverMobile}`, 120, 125)
  
  // Line items table
  const tableTop = 145
  pdf.line(20, tableTop, 190, tableTop)
  
  // Table headers
  pdf.text("Sr.", 22, tableTop + 7)
  pdf.text("Particulars", 35, tableTop + 7)
  pdf.text("HSN", 80, tableTop + 7)
  pdf.text("Qty", 100, tableTop + 7)
  pdf.text("Weight", 120, tableTop + 7)
  pdf.text("Rate", 140, tableTop + 7)
  pdf.text("Amount", 160, tableTop + 7)
  
  pdf.line(20, tableTop + 10, 190, tableTop + 10)
  
  // Table content
  let y = tableTop + 20
  invoice.lineItems.forEach((item, index) => {
    pdf.text((index + 1).toString(), 22, y)
    pdf.text(item.particulars, 35, y)
    pdf.text(item.hsn, 80, y)
    pdf.text(item.quantity.toString(), 100, y)
    pdf.text(item.weight.toString(), 120, y)
    pdf.text(item.rate.toString(), 140, y)
    pdf.text(item.amount.toFixed(2), 160, y)
    y += 10
  })
  
  // Totals
  const subtotal = invoice.lineItems.reduce((sum, item) => sum + item.amount, 0)
  const gstAmount = invoice.lineItems.reduce((sum, item) => sum + (item.amount * item.gstRate), 0)
  const additionalTotal = invoice.additionalCharges.reduce((sum, charge) => sum + charge.amount, 0)
  
  y += 10
  pdf.text(`Subtotal: ₹${subtotal.toFixed(2)}`, 140, y)
  y += 7
  pdf.text(`GST Amount: ₹${gstAmount.toFixed(2)}`, 140, y)
  y += 7
  pdf.text(`Additional Charges: ₹${additionalTotal.toFixed(2)}`, 140, y)
  y += 7
  const grandTotal = subtotal + gstAmount + additionalTotal
  pdf.text(`Grand Total: ₹${grandTotal.toFixed(2)}`, 140, y)
  
  // Bank details
  y += 20
  pdf.text("FOR RTGS / NEFT / CHEQUE", 20, y)
  y += 7
  pdf.text("SUJAY ENTERPRISES", 20, y)
  y += 7
  pdf.text("Bank: Union Bank of India", 20, y)
  y += 7
  pdf.text("A/c No.: 165721010000088", 20, y)
  y += 7
  pdf.text("IFSC: UBIN0916579", 20, y)
  
  // Terms and conditions
  y += 20
  pdf.setFontSize(8)
  pdf.text("Terms & Conditions:", 20, y)
  invoice.termsAndConditions.forEach((term, index) => {
    y += 5
    pdf.text(`${index + 1}. ${term}`, 20, y)
  })
  
  // Computer-generated receipt note
  y += 15
  pdf.text("This is a computer-generated receipt and does not require a physical signature.", 20, y)
  y += 5
  pdf.text("The invoice is valid when accompanied by online payment confirmation or company stamp.", 20, y)
  
  return pdf
}

