package com.example.gstinvoicegenerator.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun VehicleForm(
    vehicleNo: String,
    driverName: String,
    driverMobile: String,
    onInputChange: (String, String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Vehicle Details",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = vehicleNo,
                onValueChange = { onInputChange("vehicleNo", it) },
                label = { Text("Vehicle No.") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = driverName,
                onValueChange = { onInputChange("driverName", it) },
                label = { Text("Driver's Name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = driverMobile,
                onValueChange = { 
                    if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                        onInputChange("driverMobile", it)
                    }
                },
                label = { Text("Driver's Mobile") },
                modifier = Modifier.fillMaxWidth(),
                isError = driverMobile.length != 10,
                supportingText = { if (driverMobile.length != 10) Text("Mobile number should be 10 digits") }
            )
        }
    }
}

