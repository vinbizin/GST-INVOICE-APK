'use client'

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Share2, Plus, Minus, Download, Edit, Trash2 } from 'lucide-react'
import { toast } from "sonner"
import Image from "next/image"
import { gstRates, commonHsnCodes, commonItems } from "../utils/gstRates"
import { generateReferenceCode } from "../utils/referenceCode"
import { generatePDF } from "../utils/generatePDF"

interface AdditionalCharge {
  id: number
  name: string
  amount: number
}

interface LineItem {
  id: number
  particulars: string
  hsn: string
  quantity: number
  weight: number
  rate: number
  amount: number
  gstRate: number
}

interface InvoiceData {
  id: string
  referenceCode: string
  invoiceNumber: string
  date: string
  customerName: string
  address: string
  mobile: string
  panAadhar: string
  gstin: string
  vehicleNo: string
  driverName: string
  driverMobile: string
  lineItems: LineItem[]
  isInterState: boolean
  additionalCharges: AdditionalCharge[]
  termsAndConditions: string[]
}

const defaultTerms = [
  "Material once sold cannot be taken back or exchanged",
  "Goods remain our property until full payment is received",
  "Installation warranty valid for 1 year from date of installation",
  "Color warranty as per manufacturer terms",
  "Payment to be made within 30 days of invoice"
]

const emptyInvoice: InvoiceData = {
  id: '',
  referenceCode: '',
  invoiceNumber: '',
  date: new Date().toISOString().split('T')[0],
  customerName: '',
  address: '',
  mobile: '',
  panAadhar: '',
  gstin: '',
  vehicleNo: '',
  driverName: '',
  driverMobile: '',
  lineItems: [
    {
      id: 1,
      particulars: '',
      hsn: '',
      quantity: 0,
      weight: 0,
      rate: 0,
      amount: 0,
      gstRate: 0.18
    }
  ],
  isInterState: false,
  additionalCharges: [
    { id: 1, name: 'Loading Charges', amount: 0 },
    { id: 2, name: 'Transportation', amount: 0 },
    { id: 3, name: 'Installation Charges', amount: 0 }
  ],
  termsAndConditions: [...defaultTerms]
}

export default function InvoiceForm() {
  const [invoice, setInvoice] = useState<InvoiceData>(emptyInvoice)
  const [savedInvoices, setSavedInvoices] = useState<InvoiceData[]>([])
  const [newChargeName, setNewChargeName] = useState('')
  const [editMode, setEditMode] = useState(false)

  useEffect(() => {
    const storedInvoices = localStorage.getItem('savedInvoices')
    if (storedInvoices) {
      setSavedInvoices(JSON.parse(storedInvoices))
    }
  }, [])

  const saveInvoice = () => {
    if (!invoice.id) {
      invoice.id = Date.now().toString()
      invoice.referenceCode = generateReferenceCode()
    }
    const updatedInvoices = savedInvoices.some(i => i.id === invoice.id)
      ? savedInvoices.map(i => i.id === invoice.id ? invoice : i)
      : [...savedInvoices, invoice]
    setSavedInvoices(updatedInvoices)
    localStorage.setItem('savedInvoices', JSON.stringify(updatedInvoices))
    setInvoice(emptyInvoice)
    setEditMode(false)
    toast.success(editMode ? "Invoice updated successfully" : "Invoice saved successfully")
  }

  const editInvoice = (id: string) => {
    const invoiceToEdit = savedInvoices.find(i => i.id === id)
    if (invoiceToEdit) {
      setInvoice(invoiceToEdit)
      setEditMode(true)
    }
  }

  const deleteInvoice = (id: string) => {
    const updatedInvoices = savedInvoices.filter(i => i.id !== id)
    setSavedInvoices(updatedInvoices)
    localStorage.setItem('savedInvoices', JSON.stringify(updatedInvoices))
    toast.success("Invoice deleted successfully")
  }

  const calculateTotals = () => {
    const subtotal = invoice.lineItems.reduce((sum, item) => sum + item.amount, 0)
    const gstAmount = invoice.lineItems.reduce((sum, item) => sum + (item.amount * item.gstRate), 0)
    const additionalTotal = invoice.additionalCharges.reduce((sum, charge) => sum + charge.amount, 0)
    return {
      subtotal,
      gstAmount,
      additionalTotal,
      grandTotal: subtotal + gstAmount + additionalTotal
    }
  }

  return (
    <div className="container mx-auto p-4 animate-fadeIn">
      <Card className="p-6 space-y-6 shadow-lg bg-white">
        {/* Company Header */}
        <div className="flex flex-col items-center gap-4 border-b pb-6">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Sujay%20logo-1-sVoEfFwreG101KwejK4AIqel8NdHUi.png"
            alt="Sujay Enterprises Logo"
            width={200}
            height={100}
            className="h-24 object-contain"
          />
          <div className="text-center space-y-1">
            <h1 className="text-2xl font-bold text-[#1e1b4b]">SUJAY ENTERPRISES</h1>
            <p className="text-sm text-gray-600">Colour Coated Roofing Sheets & Rolling Shutter Manufacturer</p>
          </div>
          <div className="text-sm text-gray-600 text-center space-y-1">
            <p>Factory: A-95, Nardana MIDC, Hablabi Path, Dhule 424599, (MH.)</p>
            <p>Office: Plot No.24, Govardhan Nagar, Near Chavara School, Walwadi, Dhule-424002</p>
            <p>Contact: 9422787094, 7083951715</p>
            <p>GSTIN: 27BBQPB0277E1ZS | PAN: BBQPB0277E</p>
          </div>
        </div>

        {/* Invoice Details */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex gap-4">
              <Input
                type="text"
                placeholder="Invoice No."
                value={invoice.invoiceNumber}
                onChange={(e) => setInvoice({...invoice, invoiceNumber: e.target.value})}
              />
              <Input
                type="date"
                value={invoice.date}
                onChange={(e) => setInvoice({...invoice, date: e.target.value})}
              />
            </div>
            
            {/* Customer Details */}
            <Input
              type="text"
              placeholder="Customer Name"
              value={invoice.customerName}
              onChange={(e) => setInvoice({...invoice, customerName: e.target.value})}
            />
            <Textarea
              placeholder="Address"
              value={invoice.address}
              onChange={(e) => setInvoice({...invoice, address: e.target.value})}
              rows={2}
            />
            <div className="grid grid-cols-2 gap-4">
              <Input
                type="text"
                placeholder="Mobile"
                value={invoice.mobile}
                onChange={(e) => setInvoice({...invoice, mobile: e.target.value})}
              />
              <Input
                type="text"
                placeholder="PAN/Aadhar"
                value={invoice.panAadhar}
                onChange={(e) => setInvoice({...invoice, panAadhar: e.target.value})}
              />
            </div>
            <Input
              type="text"
              placeholder="GSTIN"
              value={invoice.gstin}
              onChange={(e) => setInvoice({...invoice, gstin: e.target.value})}
            />
          </div>

          {/* Vehicle Details */}
          <div className="space-y-4">
            <Input
              type="text"
              placeholder="Vehicle No."
              value={invoice.vehicleNo}
              onChange={(e) => setInvoice({...invoice, vehicleNo: e.target.value})}
            />
            <Input
              type="text"
              placeholder="Driver's Name"
              value={invoice.driverName}
              onChange={(e) => setInvoice({...invoice, driverName: e.target.value})}
            />
            <Input
              type="text"
              placeholder="Driver's Mobile"
              value={invoice.driverMobile}
              onChange={(e) => setInvoice({...invoice, driverMobile: e.target.value})}
            />
            <div className="flex items-center gap-2">
              <label className="text-sm text-gray-600">Inter-State Supply?</label>
              <input
                type="checkbox"
                checked={invoice.isInterState}
                onChange={(e) => setInvoice({...invoice, isInterState: e.target.checked})}
                className="form-checkbox h-4 w-4 text-[#1e1b4b]"
              />
            </div>
          </div>
        </div>

        {/* Line Items */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-[#1e1b4b] text-white">
                <th className="p-2 text-left">Sr.</th>
                <th className="p-2 text-left">Particulars</th>
                <th className="p-2 text-left">HSN/SAC</th>
                <th className="p-2 text-left">Qty</th>
                <th className="p-2 text-left">Weight (Kg)</th>
                <th className="p-2 text-left">Rate</th>
                <th className="p-2 text-left">GST</th>
                <th className="p-2 text-left">Amount</th>
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {invoice.lineItems.map((item, index) => (
                <tr key={item.id} className="border-b">
                  <td className="p-2">{index + 1}</td>
                  <td className="p-2">
                    <Select
                      value={item.particulars}
                      onValueChange={(value) => {
                        const newItems = [...invoice.lineItems]
                        newItems[index].particulars = value
                        setInvoice({...invoice, lineItems: newItems})
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select item" />
                      </SelectTrigger>
                      <SelectContent>
                        {commonItems.map((item) => (
                          <SelectItem key={item} value={item}>
                            {item}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="p-2">
                    <Input
                      type="text"
                      value={item.hsn}
                      onChange={(e) => {
                        const newItems = [...invoice.lineItems]
                        newItems[index].hsn = e.target.value
                        setInvoice({...invoice, lineItems: newItems})
                      }}
                      placeholder="HSN/SAC"
                    />
                  </td>
                  <td className="p-2">
                    <Input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => {
                        const newItems = [...invoice.lineItems]
                        newItems[index].quantity = Number(e.target.value)
                        newItems[index].amount = Number(e.target.value) * item.rate
                        setInvoice({...invoice, lineItems: newItems})
                      }}
                    />
                  </td>
                  <td className="p-2">
                    <Input
                      type="number"
                      value={item.weight}
                      onChange={(e) => {
                        const newItems = [...invoice.lineItems]
                        newItems[index].weight = Number(e.target.value)
                        setInvoice({...invoice, lineItems: newItems})
                      }}
                    />
                  </td>
                  <td className="p-2">
                    <Input
                      type="number"
                      value={item.rate}
                      onChange={(e) => {
                        const newItems = [...invoice.lineItems]
                        newItems[index].rate = Number(e.target.value)
                        newItems[index].amount = item.quantity * Number(e.target.value)
                        setInvoice({...invoice, lineItems: newItems})
                      }}
                    />
                  </td>
                  <td className="p-2">
                    <Select
                      value={item.gstRate.toString()}
                      onValueChange={(value) => {
                        const newItems = [...invoice.lineItems]
                        newItems[index].gstRate = Number(value)
                        setInvoice({...invoice, lineItems: newItems})
                      }}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {gstRates.map((rate) => (
                          <SelectItem key={rate.value} value={rate.value.toString()}>
                            {rate.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="p-2">
                    {(item.quantity * item.rate).toFixed(2)}
                  </td>
                  <td className="p-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        if (invoice.lineItems.length === 1) {
                          toast.error("Cannot remove the last item")
                          return
                        }
                        setInvoice({
                          ...invoice,
                          lineItems: invoice.lineItems.filter((_, i) => i !== index)
                        })
                      }}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <Button
            onClick={() => {
              setInvoice({
                ...invoice,
                lineItems: [
                  ...invoice.lineItems,
                  {
                    id: invoice.lineItems.length + 1,
                    particulars: '',
                    hsn: '',
                    quantity: 0,
                    weight: 0,
                    rate: 0,
                    amount: 0,
                    gstRate: 0.18
                  }
                ]
              })
            }}
            className="mt-4 bg-[#1e1b4b] hover:bg-[#2d2a5a]"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>

        {/* Additional Charges */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="font-semibold">Additional Charges</h3>
            {invoice.additionalCharges.map((charge, index) => (
              <div key={charge.id} className="flex gap-2">
                <Input
                  type="text"
                  value={charge.name}
                  onChange={(e) => {
                    const newCharges = [...invoice.additionalCharges]
                    newCharges[index].name = e.target.value
                    setInvoice({...invoice, additionalCharges: newCharges})
                  }}
                  placeholder="Charge Name"
                />
                <Input
                  type="number"
                  value={charge.amount}
                  onChange={(e) => {
                    const newCharges = [...invoice.additionalCharges]
                    newCharges[index].amount = Number(e.target.value)
                    setInvoice({...invoice, additionalCharges: newCharges})
                  }}
                  placeholder="Amount"
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setInvoice({
                      ...invoice,
                      additionalCharges: invoice.additionalCharges.filter((_, i) => i !== index)
                    })
                  }}
                >
                  <Minus className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <div className="flex gap-2">
              <Input
                type="text"
                value={newChargeName}
                onChange={(e) => setNewChargeName(e.target.value)}
                placeholder="New Charge Name"
              />
              <Button
                onClick={() => {
                  if (!newChargeName) return
                  setInvoice({
                    ...invoice,
                    additionalCharges: [
                      ...invoice.additionalCharges,
                      {
                        id: invoice.additionalCharges.length + 1,
                        name: newChargeName,
                        amount: 0
                      }
                    ]
                  })
                  setNewChargeName('')
                }}
              >
                Add
              </Button>
            </div>
          </div>

          {/* Totals */}
          <div className="space-y-4">
            <h3 className="font-semibold">Invoice Summary</h3>
            <div className="space-y-2 text-right">
              <p>Subtotal: ₹{calculateTotals().subtotal.toFixed(2)}</p>
              <p>GST Amount: ₹{calculateTotals().gstAmount.toFixed(2)}</p>
              <p>Additional Charges: ₹{calculateTotals().additionalTotal.toFixed(2)}</p>
              <p className="text-lg font-bold">
                Grand Total: ₹{calculateTotals().grandTotal.toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        {/* Bank Details */}
        <div className="border-t pt-6">
          <h3 className="font-semibold mb-4">Bank Details</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div>
              <p>FOR RTGS / NEFT / CHEQUE</p>
              <p>SUJAY ENTERPRISES</p>
              <p>Bank: Union Bank of India</p>
              <p>A/c No.: 165721010000088</p>
              <p>IFSC: UBIN0916579</p>
            </div>
            <div className="text-sm text-gray-600">
              <p className="font-semibold">Terms & Conditions:</p>
              <ol className="list-decimal list-inside space-y-1">
                {invoice.termsAndConditions.map((term, index) => (
                  <li key={index}>{term}</li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        {/* Computer-generated receipt note */}
        <div className="text-sm text-gray-600 mt-4 p-2 bg-gray-100 rounded">
          <p>This is a computer-generated receipt and does not require a physical signature.</p>
          <p>The invoice is valid when accompanied by online payment confirmation or company stamp.</p>
          <p>Reference Code: {invoice.referenceCode || 'Will be generated on save'}</p>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-4 pt-6 border-t">
          <Button
            variant="outline"
            onClick={saveInvoice}
          >
            {editMode ? 'Update Invoice' : 'Save Invoice'}
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setInvoice(emptyInvoice)
              setEditMode(false)
              toast.success("Form reset successfully")
            }}
          >
            Reset
          </Button>
          <Button
            onClick={() => {
              const pdf = generatePDF(invoice)
              pdf.save(`Invoice_${invoice.invoiceNumber}.pdf`)
              toast.success("PDF generated successfully!")
            }}
            className="bg-[#1e1b4b] hover:bg-[#2d2a5a]"
          >
            <Download className="w-4 h-4 mr-2" />
            Generate PDF
          </Button>
        </div>
      </Card>

      {/* Saved Invoices List */}
      <Card className="mt-8 p-6 shadow-lg bg-white">
        <h2 className="text-xl font-bold mb-4">Saved Invoices</h2>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-[#1e1b4b] text-white">
                <th className="p-2 text-left">Invoice No.</th>
                <th className="p-2 text-left">Date</th>
                <th className="p-2 text-left">Customer</th>
                <th className="p-2 text-left">Amount</th>
                <th className="p-2 text-left">Reference Code</th>
                <th className="p-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {savedInvoices.map((savedInvoice) => (
                <tr key={savedInvoice.id} className="border-b">
                  <td className="p-2">{savedInvoice.invoiceNumber}</td>
                  <td className="p-2">{savedInvoice.date}</td>
                  <td className="p-2">{savedInvoice.customerName}</td>
                  <td className="p-2">₹{calculateTotals().grandTotal.toFixed(2)}</td>
                  <td className="p-2">{savedInvoice.referenceCode}</td>
                  <td className="p-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => editInvoice(savedInvoice.id)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteInvoice(savedInvoice.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}

