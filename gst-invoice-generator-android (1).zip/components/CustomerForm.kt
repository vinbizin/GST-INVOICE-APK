import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CustomerForm(
    customerName: String,
    address: String,
    mobile: String,
    panAadhar: String,
    gstin: String,
    isInterState: Boolean,
    date: String,
    onInputChange: (String, Any) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Customer Details",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = customerName,
                onValueChange = { onInputChange("customerName", it) },
                label = { Text("Customer Name") },
                modifier = Modifier.fillMaxWidth(),
                isError = customerName.isEmpty(),
                supportingText = { if (customerName.isEmpty()) Text("Customer name is required") }
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = address,
                onValueChange = { onInputChange("address", it) },
                label = { Text("Address") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = mobile,
                onValueChange = {
                    if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                        onInputChange("mobile", it)
                    }
                },
                label = { Text("Mobile") },
                modifier = Modifier.fillMaxWidth(),
                isError = mobile.length != 10,
                supportingText = { if (mobile.length != 10) Text("Mobile number should be 10 digits") }
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = panAadhar,
                onValueChange = { onInputChange("panAadhar", it) },
                label = { Text("PAN/Aadhar") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = gstin,
                onValueChange = {
                    if (it.length <= 15) {
                        onInputChange("gstin", it.uppercase())
                    }
                },
                label = { Text("GSTIN") },
                modifier = Modifier.fillMaxWidth(),
                isError = gstin.length != 15,
                supportingText = { if (gstin.length != 15) Text("GSTIN should be 15 characters") }
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Is Inter-State")
                Switch(
                    checked = isInterState,
                    onCheckedChange = { onInputChange("isInterState", it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.primary,
                        checkedTrackColor = MaterialTheme.colorScheme.primaryContainer,
                        uncheckedThumbColor = MaterialTheme.colorScheme.secondary,
                        uncheckedTrackColor = MaterialTheme.colorScheme.secondaryContainer,
                    )
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = date,
                onValueChange = { onInputChange("date", it) },
                label = { Text("Date") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

